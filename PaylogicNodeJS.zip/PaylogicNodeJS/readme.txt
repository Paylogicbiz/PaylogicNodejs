run this command
npm install
npm start

http://localhost:3001