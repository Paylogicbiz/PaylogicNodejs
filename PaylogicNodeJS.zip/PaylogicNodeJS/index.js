"use strict"
const express = require('express');
const pug = require('pug');
const bodyParser = require("body-parser"); 
const crypto = require('crypto');
const { HmacSHA256 } = require('crypto-js');

const app = express();

app.set('view engine', 'pug');
app.use(bodyParser.urlencoded({extended :false}));

app.get('/', (req, res) => {
    res.render('index', {});
});



app.post('/sendData', (req, res) => {
    global.key1 = req.body.key;

    let return_elements = {};
     return_elements.APP_ID = req.body.APP_ID.toString();
     return_elements.ORDER_ID = req.body.order_no.toString();
     return_elements.CURRENCY_CODE = req.body.currency.toString();
     return_elements.AMOUNT = req.body.amount.toString();
     return_elements.RETURN_URL = req.body.return_url.toString();
     return_elements.TXNTYPE = req.body.txn_type;
     return_elements.CUST_NAME = req.body.cust_name;
     return_elements.CUST_EMAIL = req.body.email_id;
     return_elements.CUST_PHONE = req.body.mobile_no;
     return_elements.CUST_STREET_ADDRESS1 = req.body.street_address.toString();
     return_elements.CUST_ZIP = req.body.zip_code;
     
     if(req.body.payment_type){
     return_elements.PAYMENT_TYPE = req.body.payment_type;
    }
    if(req.body.moptype){
        return_elements.MOP_TYPE = req.body.moptype;
       }

     
     
    let ordered = sorted(return_elements);
    
    let variable = replacing(ordered)+key1;  
    let hash =HASH256(variable);
   
    let final = {};
    final.response = return_elements;
    final.hash=hash;
   
    res.render('sendData', final);
});

app.post('/response', (req, res) => {
    
    let return_elements = {};

   

    return_elements.RESPONSE_DATE_TIME = req.body.RESPONSE_DATE_TIME;
    return_elements.RESPONSE_CODE = req.body.RESPONSE_CODE;
    return_elements.STATUS = req.body.STATUS;
    return_elements.APP_ID = req.body.APP_ID;
    return_elements.TXN_ID = req.body.TXN_ID;
    return_elements.TXNTYPE = req.body.TXNTYPE;
    return_elements.RETURN_URL = req.body.RETURN_URL;
    return_elements.ORDER_ID = req.body.ORDER_ID;

    if(req.body.ACQ_ID){
        return_elements.ACQ_ID = req.body.ACQ_ID;
    }
    if(req.body.CARD_MASK){
        return_elements.CARD_MASK = req.body.CARD_MASK;
    }
    if(req.body.DUPLICATE_YN ){
        return_elements.DUPLICATE_YN = req.body.DUPLICATE_YN;
    }
    if(req.body.MOP_TYPE ){
        return_elements.MOP_TYPE = req.body.MOP_TYPE;
    }
    if(req.body.PAYMENT_TYPE ){
        return_elements.PAYMENT_TYPE = req.body.PAYMENT_TYPE;
    }
    if(req.body.RESPONSE_MESSAGE ){
        return_elements.RESPONSE_MESSAGE = req.body.RESPONSE_MESSAGE;
    }
    if(req.body.CUST_PHONE ){
        return_elements.CUST_PHONE = req.body.CUST_PHONE;
    }
    if(req.body.CUST_NAME ){
        return_elements.CUST_NAME = req.body.CUST_NAME;
    }
    if(req.body.CUST_EMAIL ){
        return_elements.CUST_EMAIL = req.body.CUST_EMAIL;
    }
    if(req.body.CURRENCY_CODE ){
        return_elements.CURRENCY_CODE = req.body.CURRENCY_CODE;
    }
    if(req.body.AMOUNT ){
        return_elements.AMOUNT = req.body.AMOUNT;
    }
    if(req.body.RRN ){
        return_elements.RRN = req.body.RRN;
    }
    if(req.body.ORIG_TXN_ID ){
        return_elements.AORIG_TXN_ID = req.body.ORIG_TXN_ID;
    }
    if(req.body.AUTH_CODE ){
        return_elements.AUTH_CODE = req.body.AUTH_CODE;
    }
    
   res.render('response',return_elements);
});



app.listen(3001, ()=>{
    console.log('server started');
});

// REPLACING OF ELEMENTS IS NECCESSARY IN SO PLEASE USE THIS FUNCTION OR CREATE YOUR ONE
function replacing(data){
    var json = JSON.stringify(data);
    const value = json.replace(/:/g,'=');
    const value1 = value.replace(/"/g,'');
    const final = value1.replace(/,/g,'~');
    const remove = final.replace(/[{}]/g,'');
    const https = remove.replace(/http=/g,'http:');// replacing return URL element
    const http = https.replace(/=3001/g,':3001'); // replacing return URL element
    return http;
  }

function HASH256(value){
      var hash = crypto.createHash('sha256');
      var data = hash.update(value);
      var data = hash.digest("hex");
      return data.toUpperCase();

}

function sorted(data){
    const ordered = Object.keys(data).sort().reduce(
        (obj, key) => { 
          obj[key] = data[key]; 
          return obj;
        }, 
        {}
      );
return ordered;

}